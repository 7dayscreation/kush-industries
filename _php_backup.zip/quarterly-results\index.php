<?php
$pageTitle = "Quarterly Results - Kush Industries Ltd.";
$pageDescription = "Quarterly Results - Kush Industries Ltd.";
$pageKeywords = "Quarterly Results - Kush Industries Ltd.";
$currentPage = "quarterly-results";
$currentSubPage = "quarterly-results";
$headerClass = "header-area header-white";
$rootPrefix = "../";
$homeLink = "../";
include dirname(__DIR__) . '/modular/head.php';
?>
<body>

<?php include dirname(__DIR__) . '/modular/header.php'; ?>

	<section class="page">
		<!-- ***** Page Top Start ***** -->
		<div class="cover">
			<div class="page-top">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<h1>Quarterly Results</h1>
						</div>
						<div class="col-lg-12">
							<ol class="breadcrumb">
								<li><a href="<?php echo $homeLink; ?>">Home</a></li>
								<li class="active">Quarterly Results</li>
							</ol>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- ***** Page Top End ***** -->

		<!-- ***** Page Content Start ***** -->
		<div class="page-bottom">
			<div class="container">
				<div class="row">
				<!-- ***** Page Content Start ***** -->
					<div class="col-lg-8 col-md-12 col-sm-12">
						<div class="blog-list">
							<div class="row">
								<!-- ***** Blog Post Big Start ***** -->
								<div class="col-lg-12">
									<div class="blog-post-thumb big">
										<div class="img">
											<img src="<?php echo $rootPrefix; ?>assets/images/investor.jpg" alt="">
										</div>
										
										<div class="text">
											<!-- Table Start ***** -->
											<table class="table-grey">
                      						<tbody>
                          						<tr class="odd">
													<h3 class="text-center"><a><strong>Quarterly Results 2022</strong></a></h3><br>
												</tr>
												<tr class="odd">
                            						<td>Financial Information - 2022-2023</td>
													<tbody>
  														<tr class="odd">
    														<td>Latest Dec 2022</td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/9b0f518b-a43a-44bd-a0bf-30edc05d94fe.pdf" target="_blank">Dec 2022</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachLive/7f65aa73-3104-4002-8fad-73e536c6ef3f.pdf" target="_blank">Sep 2022</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/c17d519d-97e6-4e07-bd5b-0728c10e3ca4.pdf" target="_blank">Jun 2022</a></td>
    													</tr>
													</tbody>
                            					</tr>
											</tbody>
											</table>
											<!-- Table End ***** -->
											<br><br><br><br>
											<!-- Table Start ***** -->
											<table class="table-grey">
                      						<tbody>
                          						<tr class="odd">
													<h3 class="text-center"><a><strong>Quarterly Results 2021</strong></a></h3><br>
												</tr>
												<tr class="odd">
                            						<td>Financial Information - 2021-2022</td>
													<tbody>
  														<tr class="odd">
    														<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/c17d519d-97e6-4e07-bd5b-0728c10e3ca4.pdf" target="_blank">March 22</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/fc3e50ea-edb5-4b1a-b2ad-95e0041d8c56.pdf" target="_blank">Dec 2021</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/b4aada8b-882b-441c-889f-621dff511b0b.pdf" target="_blank">Sep 2021</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/f8cb7ab2-5a56-4888-9444-1b0b0166b231.pdf" target="_blank">Jun 2021</a></td>
    													</tr>
													</tbody>
                            					</tr>
											</tbody>
											</table>
											<!-- Table End ***** -->
											<br><br><br><br>
											<!-- Table Start ***** -->
											<table class="table-grey">
                      						<tbody>
                          						<tr class="odd">
													<h3 class="text-center"><a><strong>Quarterly Results 2020</strong></a></h3><br>
												</tr>
												<tr class="odd">
                            						<td>Financial Information - 2020-2021</td>
													<tbody>
  														<tr class="odd">
    														<td><a href="#">Mar 2021</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/e844c95b-073a-4c7d-a037-44532274db60.pdf" target="_blank">Dec 2020</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/6db74178-285d-4af3-81a0-2d8d4291eaff.pdf" target="_blank">Sep 2020</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/5db87262-2828-424e-b81c-4d80ef903a30.pdf" target="_blank">Jun 2020</a></td>
    													</tr>
													</tbody>
                            					</tr>
											</tbody>
											</table>
											<!-- Table End ***** -->
											<br><br><br><br>
											<!-- Table Start ***** -->
											<table class="table-grey">
                      						<tbody>
                          						<tr class="odd">
													<h3 class="text-center"><a><strong>Quarterly Results 2019</strong></a></h3><br>
												</tr>
												<tr class="odd">
                            						<td>Financial Information - 2019-2020</td>
													<tbody>
  														<tr class="odd">
    														<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/044e101d-564c-498b-8861-20c972b50a41.pdf" target="_blank">Mar 2020</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/4d0cc2d7-b16c-4fe3-a65c-a1642ddf2805.pdf" target="_blank">Dec 2019</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/cff6ff9e-4315-4276-868a-8360918b7a84.pdf" target="_blank">Sep 2019</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/518236e6-7931-4670-bef7-046f9b347592.pdf " target="_blank">Jun 2019</a></td>
    													</tr>
													</tbody>
                            					</tr>
											</tbody>
											</table>
											<!-- Table End ***** -->
											<br><br><br><br>
											<!-- Table Start ***** -->
											<table class="table-grey">
                      						<tbody>
                          						<tr class="odd">
													<h3 class="text-center"><a><strong>Quarterly Results 2018</strong></a></h3><br>
												</tr>
												<tr class="odd">
                            						<td>Financial Information - 2018-2019</td>
													<tbody>
  														<tr class="odd">
    														<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/eaebdc4a-fe70-4b30-b567-d09f1248c9b0.pdf" target="_blank">Mar 2019</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/AttachHis/b9c19a91-b65d-4be2-8cfd-aafbe3dfe122.pdf" target="_blank">Dec 2018</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2018/11/b13d4c82-083f-4545-832d-42a312885722.pdf" target="_blank">Sep 2018</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2018/8/27c1e089-3ec3-4f77-8165-db6ac83708fb.pdf" target="_blank">Jun 2018</a></td>
    													</tr>
													</tbody>
                            					</tr>
											</tbody>
											</table>
											<!-- Table End ***** -->
											<br><br><br><br>
											<!-- Table Start ***** -->
											<table class="table-grey">
                      						<tbody>
                          						<tr class="odd">
													<h3 class="text-center"><a><strong>Quarterly Results 2017</strong></a></h3><br>
												</tr>
												<tr class="odd">
                            						<td>Financial Information - 2017-2018</td>
													<tbody>
  														<tr class="odd">
    														<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2018/5/695a2ca6-a950-4bb4-9338-ea6b5a1d41bb.pdf" target="_blank">Mar 2018</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2018/2/057ad3a4-41a4-4848-83ed-cb5e83c1ecde.pdf" target="_blank">Dec 2017</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2017/10/ff71dbe5-76a1-4328-98e6-e17fca1859bf.pdf" target="_blank">Sep 2017</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2017/7/ee4f5092-23c2-4cb6-bb07-f230da371912.pdf" target="_blank">Jun 2017</a></td>
    													</tr>
													</tbody>
                            					</tr>
											</tbody>
											</table>
											<!-- Table End ***** -->
											<br><br><br><br>
											<!-- Table Start ***** -->
											<table class="table-grey">
                      						<tbody>
                          						<tr class="odd">
													<h3 class="text-center"><a><strong>Quarterly Results 2016</strong></a></h3><br>
												</tr>
												<tr class="odd">
                            						<td>Financial Information - 2016-2017</td>
													<tbody>
  														<tr class="odd">
    														<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2017/4/1271DFF8_F231_4EB5_A042_CDD999F84F85_163713.pdf" target="_blank">Mar 2017</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2017/2/A02A78B3_9DD6_499D_93A6_270354B61A0A_172332.pdf" target="_blank">Dec 2016</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2016/11/A3EE3436_5CFC_4720_A8FE_3177FF32DF95_171942.pdf" target="_blank">Sep 2016</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2016/7/DCB31B24_D67A_4202_8C17_AB0829CDFF06_154454.pdf" target="_blank">Jun 2016</a></td>
    													</tr>
													</tbody>
                            					</tr>
											</tbody>
											</table>
											<!-- Table End ***** -->
											<br><br><br><br>
											<!-- Table Start ***** -->
											<table class="table-grey">
                      						<tbody>
                          						<tr class="odd">
													<h3 class="text-center"><a><strong>Quarterly Results 2015</strong></a></h3><br>
												</tr>
												<tr class="odd">
                            						<td>Financial Information - 2015-2016</td>
													<tbody>
  														<tr class="odd">
    														<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2016/5/FD56A60C_5EBC_4CC6_8727_373C66CF37F2_172041.pdf" target="_blank">Mar 2016</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2016/2/4EA00356_227E_4F71_A397_CE7C9A6CB3C5_145106.pdf" target="_blank">Dec 2015</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2015/11/F4420FDF_EF6C_4C98_83C2_9D353051C6F3_144213.pdf" target="_blank">Sep 2015</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2015/8/C9189F90_7302_474E_B42D_D0DEC756B30C_151257.pdf" target="_blank">Jun 2015</a></td>
    													</tr>
													</tbody>
                            					</tr>
											</tbody>
											</table>
											<!-- Table End ***** -->
											<br><br><br><br>
											<!-- Table Start ***** -->
											<table class="table-grey">
                      						<tbody>
                          						<tr class="odd">
													<h3 class="text-center"><a><strong>Quarterly Results 2014</strong></a></h3><br>
												</tr>
												<tr class="odd">
                            						<td>Financial Information - 2014-2015</td>
													<tbody>
  														<tr class="odd">
    														<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2015/5/D8209EB9_F055_4DEA_8F8F_D1DAF91EDD6F_162945.pdf" target="_blank">Mar 2015</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2015/2/SNS_Textiles_Ltd_130215_Rst.pdf" target="_blank">Dec 2014</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2014/11/SNS_Textiles_Ltd_131114_Rst.pdf" target="_blank">Sep 2014</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2014/8/SNS_Textiles_Ltd_130814_Rst.pdf" target="_blank">Jun 2014</a></td>
    													</tr>
													</tbody>
                            					</tr>
											</tbody>
											</table>
											<!-- Table End ***** -->
											<br><br><br><br>
											<!-- Table Start ***** -->
											<table class="table-grey">
                      						<tbody>
                          						<tr class="odd">
													<h3 class="text-center"><a><strong>Quarterly Results 2013</strong></a></h3><br>
												</tr>
												<tr class="odd">
                            						<td>Financial Information - 2013-2014</td>
													<tbody>
  														<tr class="odd">
    														<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2014/5/SNS_Textiles_Ltd_280514_Rst.pdf" target="_blank">Mar 2014</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2014/2/SNS_Textiles_Ltd_170214_Rst.pdf" target="_blank">Dec 2013</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2013/11/SNS_Textiles_Ltd_251113_Rst.pdf" target="_blank">Sep 2013</a></td>
															<td><a href="https://www.bseindia.com/xml-data/corpfiling/CorpAttachment/2013/8/SNS_Textiles_Ltd_200813_Rst.pdf" target="_blank">Jun 2013</a></td>
    													</tr>
													</tbody>
                            					</tr>
											</tbody>
											</table>
											<!-- Table End ***** -->
										</div>
									</div>
								</div>
								<!-- ***** Blog Post Big End ***** -->
							</div>
						</div>
					</div>
					<!-- ***** Page Content End ***** -->


					<?php include dirname(__DIR__) . '/modular/sidebar.php'; ?>

				</div>
			</div>
		</div>
		<!-- ***** Page Content End ***** -->
	</section>
	
<?php include dirname(__DIR__) . '/modular/footer.php'; ?>
</body>
</html>
